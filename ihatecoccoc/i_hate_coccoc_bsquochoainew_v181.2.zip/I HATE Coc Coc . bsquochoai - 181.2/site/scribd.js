﻿$(function(){
	$("body").append('<form style="position:fixed;left:0px;bottom:10px; cursor: pointer"><input id="deleteall" type="checkbox" name="deleteall" value="Bike" ><label for="deleteall">Xóa hết!</label></form>')
	
	$("#deleteall").change(function(){
		if( $(this).is(':checked') ){
			$(".zoom_in_btn").trigger("click")
			$(".global_header").hide(700).attr("style","display:none !important")
			$(".reading_mode_bar, .doc_toolbar").remove()
		} else {
			$(".global_header").removeAttr("style").show(400)
		}
		
	})
})