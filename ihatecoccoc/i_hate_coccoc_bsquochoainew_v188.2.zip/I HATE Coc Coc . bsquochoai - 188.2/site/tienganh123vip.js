$(function(){
$('html').append('<div id="paid_member"></div>')
})